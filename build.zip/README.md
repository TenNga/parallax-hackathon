
# 2020 So Far

This site is created during hackathon organize by Mintbean on 07/20/2020. 

## Quick start

Simple

- Open index.html 
- Move Cursor/move for movement effect

## Status

Successfully used Parallax.js but might update in the future

## Bugs and fix
 Applying parallax causes position of the element to top: 0, left:0 and only way to overwrite is to use !importent

## Goal

- Use Parallax.js to make a site to cover up things happen in 2020.

## Creators

- <https://github.com/TenNga>

## Thanks

- Mintbean for creating this hackathon
- Parallax.js for creating a wonderful tools 
